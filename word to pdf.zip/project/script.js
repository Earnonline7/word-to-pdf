document.addEventListener('DOMContentLoaded', () => {
  const fileInput = document.getElementById('wordFile');
  const convertBtn = document.getElementById('convertBtn');
  const status = document.getElementById('status');

  convertBtn.addEventListener('click', async () => {
    const file = fileInput.files[0];
    if (!file) {
      status.textContent = 'Please select a Word document first.';
      status.className = 'status error';
      return;
    }

    if (!file.name.match(/\.(doc|docx)$/i)) {
      status.textContent = 'Please select a valid Word document (.doc or .docx)';
      status.className = 'status error';
      return;
    }

    status.textContent = 'Converting...';
    status.className = 'status';
    convertBtn.disabled = true;

    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch('http://localhost:3000/convert', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText || 'Conversion failed');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'converted.pdf';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      status.textContent = 'Conversion successful! PDF downloaded.';
      status.className = 'status success';
    } catch (error) {
      console.error('Conversion error:', error.message);
      status.textContent = error.message || 'Error converting file. Please try again.';
      status.className = 'status error';
    } finally {
      convertBtn.disabled = false;
    }
  });
});