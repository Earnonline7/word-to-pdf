const express = require('express');
const multer = require('multer');
const cors = require('cors');
const mammoth = require('mammoth');
const path = require('path');
const fs = require('fs');
const { PDFDocument } = require('pdf-lib');

const app = express();
app.use(cors());

const upload = multer({ dest: 'uploads/' });

// Serve static files
app.use(express.static('.'));

// Create uploads directory if it doesn't exist
if (!fs.existsSync('uploads')) {
  fs.mkdirSync('uploads');
}

app.post('/convert', upload.single('file'), async (req, res) => {
  if (!req.file) {
    return res.status(400).send('No file uploaded.');
  }

  try {
    const result = await mammoth.convertToHtml({ path: req.file.path });
    
    // Create a new PDF document
    const pdfDoc = await PDFDocument.create();
    const page = pdfDoc.addPage([595.276, 841.890]); // A4 size
    
    // Add the content to the PDF
    const { width, height } = page.getSize();
    page.drawText(result.value.replace(/<[^>]*>/g, ' '), {
      x: 50,
      y: height - 50,
      size: 12,
      maxWidth: width - 100,
    });

    // Save the PDF
    const pdfBytes = await pdfDoc.save();
    
    // Clean up the uploaded file
    fs.unlinkSync(req.file.path);

    // Send the PDF file
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename=converted.pdf');
    res.send(Buffer.from(pdfBytes));
  } catch (error) {
    console.error('Error converting file:', error);
    res.status(500).send('Error converting file');
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});